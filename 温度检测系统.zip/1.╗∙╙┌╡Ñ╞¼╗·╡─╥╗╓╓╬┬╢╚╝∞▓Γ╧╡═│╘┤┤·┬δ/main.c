#include <reg51.h>
#include <intrins.h>
#include <stdio.h>

typedef unsigned int uint;
typedef unsigned char uchar;

/********************寮曡剼瀹氫箟********************/
#define LCD_DATA P0
sbit LCD_RS = P3^5;
sbit LCD_RW = P3^6;
sbit LCD_EN = P3^4;
sbit KEY_1 = P3^0;			//鍔熻兘閿?
sbit KEY_2 = P3^1;			//鍑忓皯閿?
sbit KEY_3 = P3^2;			//澧炲姞鎸夐敭
sbit DS18B20 = P2^2;
sbit dj = P1^0;
sbit fmq = P2^3;
unsigned char Counter,Compare;
/************************************************/

/********************鍏ㄥ眬鍙橀噺********************/
#define KeyTime 200					//200 * 1ms = 200ms
#define DispTime 100				//100 * 1ms = 100ms
#define UartTime 150				//150 * 1ms = 150ms
volatile uchar KEY_1ms = 0;
volatile uchar Disp_1ms = 0;
volatile uchar Uart_1ms = 0;
volatile uchar Menu = 0;		//0(鏄剧ず褰撳墠娓╁害), 1(璁剧疆鏈?浣庢俯搴?), 2(璁剧疆鏈?浣庢俯搴?)
volatile int MaxTemp = 30;
volatile int MinTemp = -10;
volatile float Temperature = 0;
/************************************************/

/********************鍑芥暟澹版槑********************/
void Delay_us(uchar x);
void Delay_ms(uchar x);
void Timer0Init(void);
void KEY_Proc(void);
void DispTemp(void);
void LCD_WriteCommand(uchar com);
void LCD_WriteData(uchar dat);
void LCD_Init(void);
void LCD_Show_Home(void);
void LCD_Show_Setting(void);
void DS18B20_Init(void);
uchar DS18B20_ReadByte(void);
void DS18B20_WriteByte(uchar dat);
float DS18B20_ReadTmp(void);
void UartInit(void);
void Uart_Proc(void);
/************************************************/

/*********************涓诲嚱鏁?*********************/
int main(void)
{ 
  fmq = 1;
	LCD_Init();
	Temperature = DS18B20_ReadTmp();
	Delay_ms(200);
	Delay_ms(200);
	UartInit();
	Timer0Init();
	LCD_Show_Home();
	while(1)
	{
		DispTemp();
		KEY_Proc();
		if(Temperature<MaxTemp) {Compare=0;}
		if(Temperature>MaxTemp&&Temperature<=33){ Compare=30; fmq = 0;}
		if(Temperature<100&&Temperature>33){ Compare=100;fmq = 0;} 
	  
	}
}
/************************************************/

/*****************寤舵椂鍑芥暟******************/
void Delay_us(uchar x)		//@12.000MHz
{
	while(x--)
	{
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	}
}

void Delay_ms(uchar x)		//@12.000MHz
{
	uchar i, j;
	while(x--)
	{
		_nop_();
		_nop_();
		i = 12;
		j = 169;
		do
		{
			while (--j);
		} while (--i);
	}
}
/************************************************/

/*******************璁℃暟鍣?0妯″潡*******************/
void Timer0Init(void)
{
	TMOD |= 0x01;	//閫夋嫨涓哄畾鏃跺櫒0妯″紡锛屽伐浣滄柟寮?1锛屼粎鐢═R0鎵撳紑鍚姩銆?
	TH0 = 0xFC;		//缁欏畾鏃跺櫒璧嬪垵鍊硷紝瀹氭椂1ms
	TL0 = 0x18;	
	ET0 = 1;			//鎵撳紑瀹氭椂鍣?0涓柇鍏佽
	EA = 1;				//鎵撳紑鎬讳腑鏂?
	TR0 = 1;			//鎵撳紑瀹氭椂鍣?
}

void Timer0(void) interrupt 1
{
	TH0 = 0xFC;		//缁欏畾鏃跺櫒璧嬪垵鍊硷紝瀹氭椂1ms
	TL0 = 0x18;
	KEY_1ms ++;
	Disp_1ms ++;
	Uart_1ms ++;
	Counter++;
	Counter%=100;
	if(Counter<Compare)
	{
			dj=1; 
	}
	if(Counter>=Compare)
	{
			dj=0; fmq = 1;
	}
}

/************************************************/

/*****************鎸夐敭妯″潡******************/
void KEY_Proc(void)
{
	if (KEY_1ms >= KeyTime)
	{
		KEY_1ms = 0;
		if (KEY_1 == 0)
		{
			Menu ++;
			LCD_Show_Setting();
			if (Menu == 3)
			{
				Menu = 0;
				LCD_Show_Home();
			}
		}
		else if (KEY_2 == 0)
		{
			if (Menu == 1)
			{
				MinTemp --;
			}
			else if (Menu == 2)
			{
				MaxTemp --;
				if ((MaxTemp - 1) == MinTemp)
				{
					MaxTemp ++;
				}
			}
		}
		else if (KEY_3 == 0)
		{
			if (Menu == 1)
			{
				MinTemp ++;
				if ((MaxTemp - 1) == MinTemp)
				{
					MinTemp --;
				}
			}
			else if (Menu == 2)
			{
				MaxTemp ++;
			}
		}
	}
}
/************************************************/

/*****************娓╁害鏄剧ず鍑芥暟******************/
void DispTemp(void)
{
	if (Disp_1ms >= DispTime)
	{
		uchar i;
		uchar Disp[6] = "      ";
		uchar Disp1[4] = "    ";
		Disp_1ms = 0;
		if (Menu == 0)
		{
			LCD_WriteCommand(0xC7);
			Temperature = DS18B20_ReadTmp();
			sprintf(Disp, "%.1f", Temperature);
			for(i=0; i<6; i++)
			{
				LCD_WriteData(Disp[i]); 
			}
		}
		else if (Menu == 1)
		{
			LCD_WriteCommand(0x80);
			LCD_WriteData('>');
			LCD_WriteCommand(0xC0);
			LCD_WriteData(' ');
			LCD_WriteCommand(0x8B);
			sprintf(Disp, "%d", MinTemp);
			for(i=0; i<4; i++)
			{
				LCD_WriteData(Disp[i]); 
			}
		}
		else if (Menu == 2)
		{
			LCD_WriteCommand(0x80);
			LCD_WriteData(' ');
			LCD_WriteCommand(0xC0);
			LCD_WriteData('>');
			LCD_WriteCommand(0xCB);
			sprintf(Disp, "%d", MaxTemp);
			for(i=0; i<4; i++)
			{
				LCD_WriteData(Disp[i]); 
			}
		}
	}
}
/************************************************/

/*******************LCD妯″潡*******************/
void LCD_WriteCommand(uchar com)
{
	LCD_EN = 0;     //浣胯兘
	LCD_RS = 0;	  	//閫夋嫨鍙戦?佸懡浠?
	LCD_RW = 0;	 	  //閫夋嫨鍐欏叆
	
	LCD_DATA = com; //鏀惧叆鍛戒护
	Delay_us(1);		//绛夊緟鏁版嵁绋冲畾

	LCD_EN = 1;	    //鍐欏叆鏃跺簭
	Delay_us(5);	  //淇濇寔鏃堕棿
	LCD_EN = 0;
}
	   
	   
void LCD_WriteData(uchar dat)
{
	LCD_EN = 0;			//浣胯兘娓呴浂
	LCD_RS = 1;			//閫夋嫨杈撳叆鏁版嵁
	LCD_RW = 0;			//閫夋嫨鍐欏叆

	LCD_DATA = dat; //鍐欏叆鏁版嵁
	Delay_us(1);

	LCD_EN = 1;   	//鍐欏叆鏃跺簭
	Delay_us(5);  	//淇濇寔鏃堕棿
	LCD_EN = 0;
}

void LCD_Init(void)
{
 	LCD_WriteCommand(0x38);  //寮?鏄剧ず
	LCD_WriteCommand(0x0C);  //寮?鏄剧ず涓嶆樉绀哄厜鏍?
	LCD_WriteCommand(0x06);  //鍐欎竴涓寚閽堝姞1
	LCD_WriteCommand(0x01);  //娓呭睆
	LCD_WriteCommand(0x80);  //璁剧疆鏁版嵁鎸囬拡璧风偣
}

void LCD_Show_Home(void)
{
	uchar i;
	uchar Disp[16];
	LCD_WriteCommand(0x80);
	sprintf(Disp, " Current Temp:  ");
	for(i=0; i<16; i++)
	{
		LCD_WriteData(Disp[i]); 
	}
	LCD_WriteCommand(0xC0);
	sprintf(Disp, " Temp:        C ");
	for(i=0; i<16; i++)
	{
		LCD_WriteData(Disp[i]); 
	}
	LCD_WriteCommand(0xCD);
	LCD_WriteData(0xDF);
}

void LCD_Show_Setting(void)
{
	uchar i;
	uchar Disp[16];
	LCD_WriteCommand(0x80);
	sprintf(Disp, " Min Temp: %d   ", MinTemp);
	for(i=0; i<16; i++)
	{
		LCD_WriteData(Disp[i]); 
	}
	LCD_WriteCommand(0xC0);
	sprintf(Disp, " Max Temp: %d   ", MaxTemp);
	for(i=0; i<16; i++)
	{
		LCD_WriteData(Disp[i]); 
	}
}
/************************************************/

/*******************DS18B20妯″潡*******************/
void DS18B20_Init(void)
{
	DS18B20 = 1;
	Delay_us(1);
	DS18B20 = 0;
	Delay_us(40);
	DS18B20 = 1;
	Delay_us(11);
}

uchar DS18B20_ReadByte(void)
{
 	uchar i,dat=0;
	DS18B20 = 1;
	for(i=0;i<8;i++)
	{
		DS18B20 = 1;
		Delay_us(1);
	 	DS18B20 = 0;
		dat >>= 1;
		DS18B20 = 1;
		if(DS18B20)
			dat |= 0X80;
		Delay_us(2);
	}
	return dat;
}

void DS18B20_WriteByte(uchar dat)
{
 	uchar i;
	for(i=0;i<8;i++)
	{
	 	DS18B20 = 0;
		DS18B20 = dat& 0x01;
		Delay_us(2);
		DS18B20 = 1;
		dat >>= 1;
	}
	Delay_us(2);
}

float DS18B20_ReadTmp(void)
{
	float Temp;
	uint Temp_Value[]={0, 0};
	DS18B20_Init();
	DS18B20_WriteByte(0xCC);
	DS18B20_WriteByte(0x44);
	Delay_us(20);
	DS18B20_Init();
	DS18B20_WriteByte(0xCC);
	DS18B20_WriteByte(0xBE);
	Temp_Value[0] = DS18B20_ReadByte(); 
	Temp_Value[1] = DS18B20_ReadByte();
	if((Temp_Value[1]&0xF8)==0xF8)
	{
		Temp = -1 * (128 - 0.0625 * (Temp_Value[0] | ((Temp_Value[1]&0x07)<<8)));
	}
	else 
	{
		Temp = 0.0625 * (Temp_Value[0] | ((Temp_Value[1]&0x07)<<8));
	}
	return Temp;
}
/************************************************/

/*******************涓插彛閫氫俊妯″潡*******************/
void UartInit(void)
{
	SCON = 0x50;		//璁剧疆涓哄伐浣滄柟寮?1
	TMOD |= 0x20;		//璁剧疆璁℃暟鍣ㄥ伐浣滄柟寮?2
	PCON = 0x80;		//娉㈢壒鐜囧姞鍊?
	TH1=0xF3;				//璁℃暟鍣ㄥ垵濮嬪?艰缃紝娉ㄦ剰娉㈢壒鐜囨槸4800鐨?
	TL1=0xF3;
//	ES=1;						//鎵撳紑鎺ユ敹涓柇
//	EA=1;						//鎵撳紑鎬讳腑鏂?
	TR1=1;					//鎵撳紑璁℃暟鍣?
}

